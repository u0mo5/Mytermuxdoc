#!/data/data/com.termux/files/usr/bin/bash
NAME=$(whoami)
if [ $NAME = root ]
then
   echo '使用root用户运行此脚本将破坏大量ruby模块'
   exit 0
else
   echo [$(date)]start
fi
cd ~
#install deb package
pkg install autoconf bison clang coreutils curl findutils git apr apr-util libffi-dev libgmp-dev libpcap-dev postgresql-dev readline-dev libsqlite-dev openssl-dev libtool libxml2-dev libxslt-dev ncurses-dev pkg-config wget make ruby-dev libgrpc-dev termux-tools ncurses ncurses-utils libsodium-dev termux-exec -y
#download msf source
aria2c https://github.com/rapid7/metasploit-framework/archive/4.16.2.tar.gz | tar xz&&mv metasploit-framework* msf
echo $?
#into work dir
cd msf
#edit gemfile
#force install rbreadline 0.5.5
#根据测试这一步会使bundler报错
#sed 's/rb-readline  (0.5.5)/rb-readline /g' -i Gemfile.lock
#sed 's/rb-readline/rb-readline (= 0.5.5)/g' -i Gemfile.lock
#install bundle
gem install bundler
#change work dir
cd ~
#install rbnacl-libsodium
#gem unpack rbnacl-libsodium -v'1.0.13'
#cd rbnacl-libsodium-1.0.13
#termux-fix-shebang ./vendor/libsodium/configure ./vendor/libsodium/build-aux/*
#sed 's|">= 3.0.1"|"~> 3.0", ">= 3.0.1"|g' -i rbnacl-libsodium.gemspec
#sed 's|">= 10"|"~> 10"|g' -i rbnacl-libsodium.gemspec
#mv ~/MSFinstall/configure.patch ~/rbnacl-libsodium*/configure.patch
#patch ./vendor/libsodium/configure < configure.patch
#gem build rbnacl-libsodium.gemspec
#gem install rbnacl-libsodium-1.0.13.gem
#cd ~
#rm -rf rbnacl-libsodium-1.0.13
#install nokogiri
gem install pkg-config
gem install nokogiri -v'1.8.0' -- --use-system-libraries
bundle config build nokogiri --use-system-libraries
#install other gems
cd ~
cd msf
rm Gemfile.lock&&cp ~/MSFinstall/Gemfile.lock Gemfile.lock
bundle install -j5 >> $HOME/MSFinstall/$(date).log
if [ $? = 0 ];then
   echo 安装结束
else
   echo 安装失败
   echo 进入$HOME/MSFinstall查看报错
fi
#remove bad script
rm modules/auxiliary/gather/http_pdf_authors.rb
#fix shebang
termux-fix-shebang msf*
echo 'exit'
