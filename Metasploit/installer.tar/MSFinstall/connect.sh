#!/data/data/com.termux/files/usr/bin/bash
if ls $PREFIX/var/lib/postgresql > /dev/null; then
  pg_ctl -D $PREFIX/var/lib/postgresql start
else
  cd $HOME/msf/config
  curl -LO https://Auxilus.github.io/database.yml
  mkdir -p $PREFIX/var/lib/postgresql
  initdb $PREFIX/var/lib/postgresql
  pg_ctl -D $PREFIX/var/lib/postgresql start
  createuser msf
  createdb msf_database
fi
